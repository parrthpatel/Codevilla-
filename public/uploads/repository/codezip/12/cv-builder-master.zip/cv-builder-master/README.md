cv-builder
==========
A Ruby on Rails App , That let you to create & Download your favorite CVs , 
This application is also incorporated with some API features like Linkedin import and Github import
