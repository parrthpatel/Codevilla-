class Keyword::Industry < Keyword::Base
  
end
