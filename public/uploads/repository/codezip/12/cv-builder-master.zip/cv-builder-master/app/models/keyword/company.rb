class Keyword::Company < Keyword::Base
  
end
