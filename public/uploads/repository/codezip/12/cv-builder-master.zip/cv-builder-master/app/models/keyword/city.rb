class Keyword::City < Keyword::Base
  
end
