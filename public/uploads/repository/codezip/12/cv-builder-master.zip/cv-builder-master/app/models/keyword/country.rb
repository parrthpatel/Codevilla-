class Keyword::Country < Keyword::Base

end
