# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CvBuilder::Application.config.secret_token = 'e86b10d621b64d57ff1677677d459fe8e5a62c93651a8cbf2797c4f83a72461cf8215994d1dbec832539960f1e52b77779ce79138f2bf9f77a010ebaff35b628'
